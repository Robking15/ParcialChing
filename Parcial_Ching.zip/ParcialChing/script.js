// ========== DATOS ==========
const DEFAULT_USER = {
  nombre: 'Ronald',
  apellido: 'Martelo Ching',
  email: 'ronald.martelo@usbctg.edu.co',
  password: 'profesor123',
  documento: '123456789',
  facultad: 'Ingenierías',
  programa: 'Ingeniería Química / Industrial',
  especialidad: 'Desarrollo Web, Algoritmos, Bases de Datos',
  metodologia: 'Enfoque práctico en resolución de algoritmos y desarrollo de proyectos web paso a paso',
  bio: 'Docente con más de 10 años de experiencia en la enseñanza de programación y desarrollo web',
  avatarInitial: 'R'
};

const SAMPLE_CLASSES = [
  {
    facultad: 'Ingeniería Química',
    nombre: 'Fundamentos de programación',
    codigo: '70560-4C0117',
    dia: 'Miércoles',
    hora: '08:00 - 10:00 AM',
    aula: 'Sala de Sistemas 4',
    estudiantes: 28
  },
  {
    facultad: 'Ingeniería Multimedia',
    nombre: 'Proyecto Integrador Web',
    codigo: '80120-3M0220',
    dia: 'Martes',
    hora: '10:00 - 12:00 AM',
    aula: 'Sala de Sistemas 2',
    estudiantes: 17
  },
  {
    facultad: 'Ingeniería Multimedia',
    nombre: 'Diseño de Interfaces',
    codigo: '80145-3D0118',
    dia: 'Viernes',
    hora: '11:00 - 1:00 PM',
    aula: 'Sala de Sistemas 1',
    estudiantes: 12
  }
];

const SCHEDULE_DATA = {
  '8:00': {
    Lunes: { text: 'Fundamentos prog. - Sala 4', color: 'green' }
  },
  '9:00': {
    Martes: { text: 'Diseño Web Sala 4', color: 'purple' },
    Jueves: { text: 'Diseño Web Sala 3', color: 'blue' }
  },
  '10:00': {
    Miércoles: { text: 'Proyecto Integrador - Sist. 2', color: 'purple' }
  }
};

const HOURS = ['7:00', '8:00', '9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00'];
const DAYS = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

// ========== ESTADO ==========
let currentUser = null;

// ========== SELECTORES ==========
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

// ========== NAVEGACIÓN ==========
function showPage(pageId) {
  $$('.page').forEach(p => p.classList.remove('active'));
  const page = document.getElementById(pageId);
  if (page) page.classList.add('active');
  $('#sidebar')?.classList.remove('open');
}

function showView(viewId) {
  $$('.view').forEach(v => v.classList.remove('active'));
  const view = document.getElementById(`view-${viewId}`);
  if (view) view.classList.add('active');

  $$('.sidebar-link').forEach(link => {
    link.classList.toggle('active', link.dataset.view === viewId);
  });
}

// ========== LOCAL STORAGE ==========
function getUsers() {
  const users = localStorage.getItem('portal_profesores_users');
  return users ? JSON.parse(users) : [];
}

function saveUser(user) {
  const users = getUsers();
  const idx = users.findIndex(u => u.email === user.email);
  if (idx >= 0) users[idx] = user;
  else users.push(user);
  localStorage.setItem('portal_profesores_users', JSON.stringify(users));
}

function findUser(email, password) {
  const users = getUsers();
  if (!users.some(u => u.email === DEFAULT_USER.email)) {
    users.push(DEFAULT_USER);
    localStorage.setItem('portal_profesores_users', JSON.stringify(users));
  }
  return users.find(u => u.email === email && u.password === password);
}

// ========== VALIDACIÓN ==========
function showError(inputId, message) {
  const input = document.getElementById(inputId);
  const errorEl = document.getElementById(`${inputId}-error`);
  if (input) input.classList.add('error');
  if (errorEl) errorEl.textContent = message;
}

function clearError(inputId) {
  const input = document.getElementById(inputId);
  const errorEl = document.getElementById(`${inputId}-error`);
  if (input) input.classList.remove('error');
  if (errorEl) errorEl.textContent = '';
}

function clearAllErrors(form) {
  form.querySelectorAll('.error-msg').forEach(el => el.textContent = '');
  form.querySelectorAll('.error').forEach(el => el.classList.remove('error'));
}

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// ========== LOGIN ==========
$('#login-form')?.addEventListener('submit', (e) => {
  e.preventDefault();
  clearAllErrors(e.target);

  const email = $('#login-email').value.trim();
  const password = $('#login-password').value;
  let valid = true;

  if (!email) {
    showError('login-email', 'El correo es obligatorio');
    valid = false;
  } else if (!validateEmail(email)) {
    showError('login-email', 'Correo no válido');
    valid = false;
  }

  if (!password) {
    showError('login-password', 'La contraseña es obligatoria');
    valid = false;
  }

  if (!valid) return;

  const user = findUser(email, password);
  if (!user) {
    showError('login-password', 'Correo o contraseña incorrectos');
    return;
  }

  currentUser = user;
  localStorage.setItem('portal_current_user', JSON.stringify(user));
  loadUserData();
  showPage('app');
  showView('dashboard');
});

// ========== REGISTRO ==========
$('#register-form')?.addEventListener('submit', (e) => {
  e.preventDefault();
  clearAllErrors(e.target);

  const nombre = $('#reg-nombre').value.trim();
  const apellido = $('#reg-apellido').value.trim();
  const email = $('#reg-email').value.trim();
  const documento = $('#reg-documento').value.trim();
  const password = $('#reg-password').value;
  const facultad = $('#reg-facultad').value;
  const especialidad = $('#reg-especialidad').value.trim();
  const metodologia = $('#reg-metodologia').value.trim();

  let valid = true;

  if (!nombre) { showError('reg-nombre', 'Nombre obligatorio'); valid = false; }
  if (!apellido) { showError('reg-apellido', 'Apellido obligatorio'); valid = false; }
  if (!email) {
    showError('reg-email', 'Correo obligatorio');
    valid = false;
  } else if (!validateEmail(email)) {
    showError('reg-email', 'Correo no válido');
    valid = false;
  } else if (getUsers().some(u => u.email === email)) {
    showError('reg-email', 'Este correo ya está registrado');
    valid = false;
  }
  if (!documento) { showError('reg-documento', 'Documento obligatorio'); valid = false; }
  if (!password || password.length < 6) {
    showError('reg-password', 'Mínimo 6 caracteres');
    valid = false;
  }
  if (!facultad) { showError('reg-facultad', 'Selecciona una facultad'); valid = false; }

  if (!valid) return;

  const newUser = {
    nombre,
    apellido,
    email,
    password,
    documento,
    facultad,
    programa: facultad,
    especialidad: especialidad || 'Sin especificar',
    metodologia: metodologia || 'No especificada',
    bio: 'Docente registrado en el portal.',
    avatarInitial: nombre.charAt(0).toUpperCase()
  };

  saveUser(newUser);
  currentUser = newUser;
  localStorage.setItem('portal_current_user', JSON.stringify(newUser));
  e.target.reset();
  loadUserData();
  showPage('app');
  showView('dashboard');
  showModal('¡Registro exitoso!', 'Tu cuenta ha sido creada. Ya puedes gestionar tus clases.');
});

// ========== CARGAR DATOS ==========
function loadUserData() {
  if (!currentUser) return;

  const fullName = `${currentUser.nombre} ${currentUser.apellido}`;

  $('#dash-nombre').textContent = currentUser.nombre;
  $('#dash-facultad').textContent = `${currentUser.facultad} - Periodo 2026-01`;
  $('#header-avatar').textContent = currentUser.avatarInitial || currentUser.nombre.charAt(0);

  $('#perfil-nombre').textContent = fullName;
  $('#perfil-email').textContent = currentUser.email;
  $('#perfil-facultad').textContent = currentUser.facultad;
  $('#perfil-programa').textContent = currentUser.programa || currentUser.facultad;
  $('#perfil-metodologia').textContent = currentUser.metodologia;
  $('#perfil-bio').textContent = currentUser.bio;

  const tagsContainer = $('#perfil-especialidades');
  if (tagsContainer && currentUser.especialidad) {
    const tags = currentUser.especialidad.split(',').map(t => t.trim()).filter(Boolean);
    tagsContainer.innerHTML = tags.map(t => `<span class="tag">${t}</span>`).join('');
  }
}

// ========== RENDER CLASES ==========
function renderClasses() {
  const grid = $('#classes-grid');
  if (!grid) return;

  grid.innerHTML = SAMPLE_CLASSES.map(cls => {
    // Solo Fundamentos de programación abre el PDF real
    const isFundamentos = cls.nombre.toLowerCase().includes('fundamentos de programación');

    const botonSyllabus = isFundamentos
      ? `<a href="docs/fundamentos-programacion.pdf" target="_blank" class="btn btn-primary">Ver Syllabus</a>`
      : `<button class="btn btn-primary" data-syllabus="${cls.nombre}">Ver Syllabus</button>`;

    return `
      <article class="class-card">
        <span class="faculty">${cls.facultad}</span>
        <h3>${cls.nombre}</h3>
        <p class="code">Código: ${cls.codigo}</p>
        <div class="class-meta">
          <span>🕒 ${cls.dia} ${cls.hora}</span>
          <span>📍 ${cls.aula}</span>
          <span>👥 ${cls.estudiantes} Estudiantes</span>
        </div>
        ${botonSyllabus}
      </article>
    `;
  }).join('');

  // Solo los botones que no son enlace (las otras materias)
  grid.querySelectorAll('button[data-syllabus]').forEach(btn => {
    btn.addEventListener('click', () => {
      showModal('Syllabus', `Información del syllabus de <strong>${btn.dataset.syllabus}</strong> (prototipo).`);
    });
  });
}

// ========== RENDER HORARIO ==========
function renderSchedule() {
  const tbody = $('#schedule-body');
  if (!tbody) return;

  tbody.innerHTML = HOURS.map(hour => {
    const cells = DAYS.map(day => {
      const data = SCHEDULE_DATA[hour]?.[day];
      if (data) {
        return `<td><div class="class-block ${data.color}">${data.text}</div></td>`;
      }
      return '<td></td>';
    }).join('');
    return `<tr><td><strong>${hour}</strong></td>${cells}</tr>`;
  }).join('');
}

// ========== MODAL GENÉRICO ==========
function showModal(title, bodyHtml) {
  $('#modal-title').textContent = title;
  $('#modal-body').innerHTML = bodyHtml;
  $('#modal-overlay').hidden = false;
}

$('#modal-close')?.addEventListener('click', () => {
  $('#modal-overlay').hidden = true;
});

$('#modal-overlay')?.addEventListener('click', (e) => {
  if (e.target === e.currentTarget) $('#modal-overlay').hidden = true;
});

// ========== AGREGAR MATERIA (solo visual) ==========
function openAgregarMateria() {
  $('#modal-agregar-materia').hidden = false;
  $('#form-agregar-materia').reset();
}

function closeAgregarMateria() {
  $('#modal-agregar-materia').hidden = true;
}

$('#btn-agregar-materia')?.addEventListener('click', openAgregarMateria);
$('#btn-agregar-horario')?.addEventListener('click', openAgregarMateria);
$('#btn-cancelar-materia')?.addEventListener('click', closeAgregarMateria);

$('#form-agregar-materia')?.addEventListener('submit', (e) => {
  e.preventDefault();
  closeAgregarMateria();
  showModal('Materia registrada', 'La materia se ha registrado correctamente (prototipo visual). En una versión real se guardaría en la base de datos.');
});

$('#modal-agregar-materia')?.addEventListener('click', (e) => {
  if (e.target === e.currentTarget) closeAgregarMateria();
});

// ========== TOGGLE PASSWORD ==========
$$('.toggle-password').forEach(btn => {
  btn.addEventListener('click', () => {
    const input = btn.previousElementSibling;
    if (input.type === 'password') {
      input.type = 'text';
      btn.textContent = '🙈';
    } else {
      input.type = 'password';
      btn.textContent = '👁';
    }
  });
});

// ========== EVENTOS DE NAVEGACIÓN ==========
$$('[data-page]').forEach(el => {
  el.addEventListener('click', (e) => {
    e.preventDefault();
    showPage(el.dataset.page);
  });
});

$$('[data-view]').forEach(el => {
  el.addEventListener('click', () => {
    if (el.dataset.view) showView(el.dataset.view);
  });
});

// ========== SIDEBAR COLAPSABLE ==========
$('#sidebar-toggle')?.addEventListener('click', () => {
  $('#sidebar').classList.toggle('collapsed');
});

$('#mobile-menu-btn')?.addEventListener('click', () => {
  $('#sidebar').classList.toggle('open');
});

// ========== AVATAR → PERFIL ==========
$('#header-avatar')?.addEventListener('click', () => {
  showView('perfil');
});

// ========== LOGOUT ==========
$('#logout-btn')?.addEventListener('click', () => {
  currentUser = null;
  localStorage.removeItem('portal_current_user');
  showPage('landing');
  $('#login-form')?.reset();
  clearAllErrors($('#login-form'));
});

// ========== INICIALIZACIÓN ==========
document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('portal_current_user');
  if (saved) {
    currentUser = JSON.parse(saved);
    loadUserData();
    showPage('app');
    showView('dashboard');
  } else {
    showPage('landing');
  }

  renderClasses();
  renderSchedule();
});